# Code Citations

## License: неизвестно
https://github.com/sidappinventiv/api/tree/468b2f8e9990b4dcc2ff14b2b3c2319a7c5c85e0/index.ts

```
import express from 'express';
import userRoutes from './routes/userRoutes';

const app = express();
const PORT = 3000;

app.use(express.json());
app.use('/api/users', userRoutes);
```

