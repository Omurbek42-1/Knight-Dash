export interface Game {
    id: string;
    boardState: string[][];
    currentPlayer: Player;
    status: 'ongoing' | 'finished';
}

export interface Move {
    from: string;
    to: string;
    player: Player;
}

export interface Player {
    id: string;
    name: string;
    color: 'white' | 'black';
}