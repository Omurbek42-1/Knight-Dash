import jwt from 'jsonwebtoken';

export class UserService {
    private users: Map<string, any>;

    constructor() {
        this.users = new Map();
    }

    // Авторизация пользователя
    public authenticateUser(login: string, telephone: string) {
        let user = this.users.get(login);

        if (!user) {
            // Если пользователь не существует, создаём нового
            user = { login, telephone, score: 0 };
            this.users.set(login, user);
        }

        // Генерация токена
        const token = this.generateToken(user);

        return { user, token };
    }

    // Обработка результатов игры
    public updateScore(token: string, score: number) {
        const decoded: any = this.verifyToken(token);
        const user = this.users.get(decoded.login);

        if (!user) {
            throw new Error('User not found');
        }

        // Обновляем рекорд, если новый результат выше
        if (score > user.score) {
            user.score = score;
        }

        return user;
    }

    // Получение топ-10 игроков
    public getTopPlayers() {
        const allUsers = Array.from(this.users.values());
        return allUsers
            .sort((a, b) => b.score - a.score) // Сортируем по очкам
            .slice(0, 10); // Возвращаем только топ-10
    }

    // Генерация токена
    private generateToken(user: any) {
        const secretKey = 'your_secret_key'; // Замените на безопасный ключ
        return jwt.sign({ login: user.login }, secretKey, { expiresIn: '1h' });
    }

    // Проверка токена
    private verifyToken(token: string) {
        const secretKey = 'your_secret_key'; // Замените на безопасный ключ
        return jwt.verify(token, secretKey);
    }
}