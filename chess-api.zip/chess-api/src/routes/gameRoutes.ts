import { Router } from 'express';
import { GameController } from '../controllers/gameController';

const router = Router();
const gameController = new GameController();

export function setGameRoutes(app: Router) {
    app.post('/games', gameController.createGame.bind(gameController));
    app.get('/games/:id', gameController.getGame.bind(gameController));
    app.post('/games/:id/move', gameController.makeMove.bind(gameController));
    app.delete('/games/:id', gameController.endGame.bind(gameController));
}