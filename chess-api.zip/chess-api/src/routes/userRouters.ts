import { Router } from 'express';
import { UserController } from '../controllers/userController';

const router = Router();
const userController = new UserController();

// Авторизация
router.post('/auth', (req, res) => userController.authenticateUser(req, res));

// Обработка результатов игры
router.post('/game/result', (req, res) => userController.updateScore(req, res));

// Получение топ-10 игроков
router.get('/leaderboard', (req, res) => userController.getTopPlayers(req, res));

export default router;