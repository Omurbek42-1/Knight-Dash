export class GameModel {
    id: string;
    boardState: string[][];
    currentPlayer: string;

    constructor(id: string, boardState: string[][], currentPlayer: string) {
        this.id = id;
        this.boardState = boardState;
        this.currentPlayer = currentPlayer;
    }

    updateBoard(newBoardState: string[][]) {
        this.boardState = newBoardState;
    }

    switchPlayer() {
        this.currentPlayer = this.currentPlayer === 'white' ? 'black' : 'white';
    }

    isValidKnightMove(start: [number, number], end: [number, number]): boolean {
        const [startX, startY] = start;
        const [endX, endY] = end;

        // Разница по координатам
        const dx = Math.abs(endX - startX);
        const dy = Math.abs(endY - startY);

        // Ход коня: либо 2 клетки по одной оси и 1 по другой
        return (dx === 2 && dy === 1) || (dx === 1 && dy === 2);
    }
}