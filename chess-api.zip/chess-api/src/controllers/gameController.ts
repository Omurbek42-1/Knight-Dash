import { Request, Response } from 'express';
import { GameService } from '../services/gameService';

export class GameController {
    private gameService: GameService;

    constructor() {
        this.gameService = new GameService();
    }

    public createGame(req: Request, res: Response): void {
        try {
            const gameId = 'game-' + Date.now();
            const initialBoardState = [
                ['R', 'N', 'B', 'Q', 'K', 'B', 'N', 'R'],
                ['P', 'P', 'P', 'P', 'P', 'P', 'P', 'P'],
                ['', '', '', '', '', '', '', ''],
                ['', '', '', '', '', '', '', ''],
                ['', '', '', '', '', '', '', ''],
                ['', '', '', '', '', '', '', ''],
                ['p', 'p', 'p', 'p', 'p', 'p', 'p', 'p'],
                ['r', 'n', 'b', 'q', 'k', 'b', 'n', 'r'],
            ];
            const currentPlayer = 'white';
            const game = this.gameService.createGame(gameId, initialBoardState, currentPlayer);
            res.status(201).json(game);
        } catch (error) {
            res.status(500).json({ message: 'Failed to create game', error: error.message });
        }
    }
}