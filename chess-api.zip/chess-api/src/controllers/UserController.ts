import { Request, Response } from 'express';
import { UserService } from '../services/userService';

export class UserController {
    private userService: UserService;

    constructor() {
        this.userService = new UserService();
    }

    // Авторизация пользователя
    public authenticateUser(req: Request, res: Response): void {
        try {
            const { login, telephone } = req.body;
            if (!login || !telephone) {
                return res.status(400).json({ message: 'Login and telephone are required' });
            }

            const result = this.userService.authenticateUser(login, telephone);
            res.status(200).json(result);
        } catch (error) {
            res.status(400).json({ message: error.message });
        }
    }

    // Обработка результатов игры
    public updateScore(req: Request, res: Response): void {
        try {
            const { token, score } = req.body;
            if (!token || score === undefined) {
                return res.status(400).json({ message: 'Token and score are required' });
            }

            const user = this.userService.updateScore(token, score);
            res.status(200).json(user);
        } catch (error) {
            res.status(400).json({ message: error.message });
        }
    }

    // Получение топ-10 игроков
    public getTopPlayers(req: Request, res: Response): void {
        try {
            const topPlayers = this.userService.getTopPlayers();
            res.status(200).json(topPlayers);
        } catch (error) {
            res.status(500).json({ message: 'Failed to fetch top players', error: error.message });
        }
    }
}